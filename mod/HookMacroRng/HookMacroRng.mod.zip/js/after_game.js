window.hookMacroRng.initHook(Macro);
